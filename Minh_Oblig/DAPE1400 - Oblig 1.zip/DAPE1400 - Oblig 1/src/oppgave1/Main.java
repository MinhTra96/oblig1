package oppgave1;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        double radius = Double.parseDouble(JOptionPane.showInputDialog("Radius:"));

        Sirkel sirkel1 = new Sirkel(radius);
        sirkel1.areal();
        sirkel1.diameter();
        sirkel1.omkrets();
    }
}
